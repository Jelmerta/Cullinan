package se.citerus.dddsample.domain.model.location;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import util.CullinanId;
import util.CullinanReference;

public class SampleLocations implements CullinanReference {

    public static final Location HONGKONG = (Location) SampleLocationsClient.getConstant("HONGKONG");
    public static final Location MELBOURNE = (Location) SampleLocationsClient.getConstant("MELBOURNE");
    public static final Location STOCKHOLM = (Location) SampleLocationsClient.getConstant("STOCKHOLM");
    public static final Location HELSINKI = (Location) SampleLocationsClient.getConstant("HELSINKI");
    public static final Location CHICAGO = (Location) SampleLocationsClient.getConstant("CHICAGO");
    public static final Location TOKYO = (Location) SampleLocationsClient.getConstant("TOKYO");
    public static final Location HAMBURG = (Location) SampleLocationsClient.getConstant("HAMBURG");
    public static final Location SHANGHAI = (Location) SampleLocationsClient.getConstant("SHANGHAI");
    public static final Location ROTTERDAM = (Location) SampleLocationsClient.getConstant("ROTTERDAM");
    public static final Location GOTHENBURG = (Location) SampleLocationsClient.getConstant("GOTHENBURG");
    public static final Location HANGZOU = (Location) SampleLocationsClient.getConstant("HANGZOU");
    public static final Location NEWYORK = (Location) SampleLocationsClient.getConstant("NEWYORK");
    public static final Location DALLAS = (Location) SampleLocationsClient.getConstant("DALLAS");

    public static final Map<UnLocode, Location> ALL = new HashMap<UnLocode, Location>();

    static {
        for (Field field : SampleLocations.class.getDeclaredFields()) {
            if (field.getType().equals(Location.class)) {
                try {
                    Location location = ((Location) (field.get(null)));
                    SampleLocations.ALL.put(location.unLocode(), location);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static List<Location> getAll() {
        return new ArrayList<Location>(SampleLocations.ALL.values());
    }

    public static Location lookup(UnLocode unLocode) {
        return SampleLocations.ALL.get(unLocode);
    }

    private CullinanId referenceId;

    public CullinanId getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(CullinanId referenceId) {
        this.referenceId = referenceId;
    }

    public SampleLocations(CullinanId referenceId) {
        this.referenceId = referenceId;
    }
}