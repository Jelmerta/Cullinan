package se.citerus.dddsample.domain.model.location;
import se.citerus.dddsample.domain.shared.Entity;
import util.CullinanId;
import util.CullinanReference;
public class Location implements CullinanReference , Entity<Location> {
    /**
     * Special Location object that marks an unknown location.
     */
    public static final Location UNKNOWN = (Location) SampleLocationsClient.getConstant("UNKNOWN");

    /**
     * Package-level constructor, visible for test only.
     *
     * @param unLocode
     * 		UN Locode
     * @param name
     * 		location name
     * @throws IllegalArgumentException
     * 		if the UN Locode or name is null
     */
    Location(final UnLocode unLocode, final String name) {
        this.referenceId = LocationClient.newLocation(unLocode, name);
    }

    /**
     *
     * @return UN Locode for this location.
     */
    public UnLocode unLocode() {
        return LocationClient.unLocode(referenceId);
    }

    /**
     *
     * @return Actual name of this location, e.g. "Stockholm".
     */
    public String name() {
        return LocationClient.name(referenceId);
    }

    /**
     *
     * @param object
     * 		to compare
     * @return Since this is an entiy this will be true iff UN locodes are equal.
     */
    @Override
    public boolean equals(final Object object) {
        return LocationClient.equals(referenceId, object);
    }

    @Override
    public boolean sameIdentityAs(final Location other) {
        return LocationClient.sameIdentityAs(referenceId, other);
    }

    /**
     *
     * @return Hash code of UN locode.
     */
    @Override
    public int hashCode() {
        return LocationClient.hashCode(referenceId);
    }

    @Override
    public String toString() {
        return LocationClient.toString(referenceId);
    }

    // TODO Cullinan would generate service function here, Hibernate wants empty implementation...?
    Location() {
//        this.referenceId = LocationClient.newLocation();
    }

    private CullinanId referenceId;

    public CullinanId getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(CullinanId referenceId) {
        this.referenceId = referenceId;
    }

    public Location(CullinanId referenceId) {
        this.referenceId = referenceId;
    }
}