package se.citerus.dddsample.domain.model.location;
import client.rmiinterface.UnLocodeInterface;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import util.CullinanId;
import util.SerializationUtil;
public class UnLocodeClient {
    static {
        try {
            Registry registry = LocateRegistry.getRegistry();
            service = ((UnLocodeInterface) (registry.lookup("//localhost/UnLocode")));
        } catch (NotBoundException | RemoteException e) {
            throw new RuntimeException(e);
        }
    }

    private static UnLocodeInterface service;

    public static boolean equals(CullinanId objectReferenceId, final Object o) {
        try {
            String oEncoded = SerializationUtil.encode(o);
            return service.equals(objectReferenceId.getIdValue(), oEncoded);
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static int hashCode(CullinanId objectReferenceId) {
        try {
            return service.hashCode(objectReferenceId.getIdValue());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static String idString(CullinanId objectReferenceId) {
        try {
            return service.idString(objectReferenceId.getIdValue());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static boolean sameValueAs(CullinanId objectReferenceId, UnLocode other) {
        try {
            String otherEncoded = SerializationUtil.encode(other);
            return service.sameValueAs(objectReferenceId.getIdValue(), otherEncoded);
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static String toString(CullinanId objectReferenceId) {
        try {
            return service.toString(objectReferenceId.getIdValue());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static CullinanId newUnLocode() {
        try {
            return new CullinanId(service.newUnLocode());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static CullinanId newUnLocode(final String countryAndLocation) {
        try {
            return new CullinanId(service.newUnLocode(countryAndLocation));
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static Location findLocation(CullinanId referenceId) {
        try {
            String encodedServiceResult = service.findLocation(referenceId.getIdValue());
            return (Location) SerializationUtil.decode(encodedServiceResult);
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }
}