package se.citerus.dddsample.domain.model.handling;
import se.citerus.dddsample.domain.model.location.UnLocode;
import util.CullinanId;
import util.CullinanReference;
public class UnknownLocationException extends CannotCreateHandlingEventException implements CullinanReference {
    public UnknownLocationException(final UnLocode unlocode) {
        this.referenceId = UnknownLocationExceptionClient.newUnknownLocationException(unlocode);
    }

    @Override
    public String getMessage() {
        return UnknownLocationExceptionClient.getMessage(referenceId);
    }

    private CullinanId referenceId;

    public CullinanId getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(CullinanId referenceId) {
        this.referenceId = referenceId;
    }

    public UnknownLocationException(CullinanId referenceId) {
        this.referenceId = referenceId;
    }
}