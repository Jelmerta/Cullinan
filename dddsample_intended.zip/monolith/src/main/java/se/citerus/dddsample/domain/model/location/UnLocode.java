package se.citerus.dddsample.domain.model.location;
import se.citerus.dddsample.domain.shared.ValueObject;
import util.CullinanId;
import util.CullinanReference;
public class UnLocode implements CullinanReference , ValueObject<UnLocode> {
    /**
     * Constructor.
     *
     * @param countryAndLocation
     * 		Location string.
     */
    public UnLocode(final String countryAndLocation) {
        this.referenceId = UnLocodeClient.newUnLocode(countryAndLocation);
    }

    /**
     *
     * @return country code and location code concatenated, always upper case.
     */
    public String idString() {
        return UnLocodeClient.idString(referenceId);
    }

    @Override
    public boolean equals(final Object o) {
        return UnLocodeClient.equals(referenceId, o);
    }

    @Override
    public int hashCode() {
        return UnLocodeClient.hashCode(referenceId);
    }

    @Override
    public boolean sameValueAs(UnLocode other) {
        return UnLocodeClient.sameValueAs(referenceId, other);
    }

    @Override
    public String toString() {
        return UnLocodeClient.toString(referenceId);
    }

    UnLocode() {
        this.referenceId = UnLocodeClient.newUnLocode();
    }

    private CullinanId referenceId;

    public CullinanId getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(CullinanId referenceId) {
        this.referenceId = referenceId;
    }

    // Needed for proxy creation
    public UnLocode(CullinanId referenceId) {
        this.referenceId = referenceId;
    }

    public Location findLocation() {
        return UnLocodeClient.findLocation(referenceId);
    }
}