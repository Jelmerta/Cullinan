package se.citerus.dddsample.domain.model.handling;
import client.rmiinterface.UnknownLocationExceptionInterface;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import se.citerus.dddsample.domain.model.location.UnLocode;
import util.CullinanId;
import util.SerializationUtil;
public class UnknownLocationExceptionClient {
    static {
        try {
            Registry registry = LocateRegistry.getRegistry();
            service = ((UnknownLocationExceptionInterface) (registry.lookup("//localhost/UnknownLocationException")));
        } catch (NotBoundException | RemoteException e) {
            throw new RuntimeException(e);
        }
    }

    private static UnknownLocationExceptionInterface service;

    public static String getMessage(CullinanId objectReferenceId) {
        try {
            return service.getMessage(objectReferenceId.getIdValue());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static CullinanId newUnknownLocationException(final UnLocode unlocode) {
        try {
            String unlocodeEncoded = SerializationUtil.encode(unlocode);
            return new CullinanId(service.newUnknownLocationException(unlocodeEncoded));
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }
}