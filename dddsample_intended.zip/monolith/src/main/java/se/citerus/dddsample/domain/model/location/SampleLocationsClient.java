package se.citerus.dddsample.domain.model.location;
import client.rmiinterface.SampleLocationsInterface;
import util.SerializationUtil;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
public class SampleLocationsClient {
    static {
        try {
            Registry registry = LocateRegistry.getRegistry();
            service = ((SampleLocationsInterface) (registry.lookup("//localhost/SampleLocations")));
        } catch (NotBoundException | RemoteException e) {
            throw new RuntimeException(e);
        }
    }

    private static SampleLocationsInterface service;

    public static String newSampleLocations() {
        try {
            return service.newSampleLocations();
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static Object getConstant(String constantName) {
        try {
            String encoded = service.getConstant(constantName);
            return SerializationUtil.decode(encoded);
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }
}