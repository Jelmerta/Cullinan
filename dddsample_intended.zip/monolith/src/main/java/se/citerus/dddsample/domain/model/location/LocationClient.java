package se.citerus.dddsample.domain.model.location;
import client.rmiinterface.LocationInterface;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.stream.Collectors;

import util.CullinanId;
import util.SerializationUtil;
public class LocationClient {
    static {
        try {
            Registry registry = LocateRegistry.getRegistry();
            service = ((LocationInterface) (registry.lookup("//localhost/Location")));
        } catch (NotBoundException | RemoteException e) {
            throw new RuntimeException(e);
        }
    }

    private static LocationInterface service;

    public static boolean equals(CullinanId objectReferenceId, final Object object) {
        try {
            String objectEncoded = SerializationUtil.encode(object);
            return service.equals(objectReferenceId.getIdValue(), objectEncoded);
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static int hashCode(CullinanId objectReferenceId) {
        try {
            return service.hashCode(objectReferenceId.getIdValue());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static String name(CullinanId objectReferenceId) {
        try {
            return service.name(objectReferenceId.getIdValue());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static boolean sameIdentityAs(CullinanId objectReferenceId, final Location other) {
        try {
            String otherEncoded = SerializationUtil.encode(other);
            return service.sameIdentityAs(objectReferenceId.getIdValue(), otherEncoded);
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static String toString(CullinanId objectReferenceId) {
        try {
            return service.toString(objectReferenceId.getIdValue());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static UnLocode unLocode(CullinanId objectReferenceId) {
        try {
            String encodedServiceResult = service.unLocode(objectReferenceId.getIdValue());
            return ((UnLocode) (SerializationUtil.decode(encodedServiceResult)));
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static CullinanId newLocation() {
        try {
            return new CullinanId(service.newLocation());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static CullinanId newLocation(final UnLocode unLocode, final String name) {
        try {
            String unLocodeEncoded = SerializationUtil.encode(unLocode);
            return new CullinanId(service.newLocation(unLocodeEncoded, name));
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }

    public static List<Location> findAll() {
        try {
            return service.findAll().stream()
                    .map(locationReference -> (Location) SerializationUtil.decode(locationReference))
                    .collect(Collectors.toList());
        } catch (RemoteException exception) {
            throw new RuntimeException(exception);
        }
    }
}