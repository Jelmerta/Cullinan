package util;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;
public class SerializationUtil {
    private static final Set<String> serviceClassDefinitions = new HashSet<>();

    private static final Set<String> proxyClassDefinitions = new HashSet<>();

    private SerializationUtil() {
    }

    public static String encode(Object object) {
        // TODO How do we handle null? How does IBM handle null?
        if (object == null) {
            return null;
        }
        String className = object.getClass().getName();
        if (isServiceClass(className) || isProxyClass(className)) {
            CullinanReference cullinanReference = ((CullinanReference) (object));
            return cullinanReference.getReferenceId().getIdValue();// (className + "::") + TODO IS this required or is reference always containing this?
        } else {
            return encodeByte64(object);
        }
    }

    // TODO Don't we know from for example the name in the interface whether to decode or to retrieve from storage...?
    // TODO Should we have one storage, that would help here? Otherwise we need to decide in the client/service class instead of here whether to referenceid vs byte64...
    public static Object decode(String serialized) {
        if (serialized == null) {
//            throw new IllegalArgumentException("Did not expect serialized object to be null");
            // Maybe we just allow null objects? Like equals(null) should be allowed? Kind of depends I guess.        }
            return null;
        }
        String[] split = serialized.split("::");
        if ((split.length < 1) || (split.length > 2)) {
            throw new IllegalArgumentException("Expected :: to be contained 0 or 1 time in the serialized object, meaning there are either 1 or 2 parts splits");// TODO Is this too strict? This probably might happen? We could also just take the last occurence of ::?
        }
        if (split.length == 1) {
            return decodeByte64(serialized);
        }
        // Split.length == 2 (:: is contained once)
        String className = split[0];
        String referenceId = split[1];
        if (isServiceClass(className)) {
            return StorageManager.get(serialized);// TODO Only reference id or the whole type::referenceId String?

        } else if (isProxyClass(className)) {
            // Get class
            try {
                // TODO Constructor or static method...?
                // Use constructor with custom reference id object? Or we could make a public static instanceCreator for proxy objects.
                // CullinanId cullinanId = new CullinanId(referenceId);
                // classType.getConstructor()
                Class<?> classType = Class.forName(className);
                Constructor<?> createProxyConstructor = classType.getConstructor(CullinanId.class);
                CullinanId cullinanId = new CullinanId(serialized);
                return createProxyConstructor.newInstance(cullinanId);
            } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InvocationTargetException | InstantiationException e) {
                throw new RuntimeException(e);
            }
            // Call constructor
            // return Object
            // In caller, Cast to the correct type
        } else {
            throw new IllegalStateException(((("Unknown class " + className) + " with reference id ") + referenceId) + " passed.");
        }
    }

    private static String encodeByte64(Object object) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(object);
            objectOutputStream.close();
            return Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static Object decodeByte64(String encoded) {
        try {
            byte[] data = Base64.getDecoder().decode(encoded);
            ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(data));
            Object object = objectInputStream.readObject();
            objectInputStream.close();
            return object;
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static boolean isProxyClass(String className) {
        return proxyClassDefinitions.contains(className);
    }

    private static boolean isServiceClass(String className) {
        return serviceClassDefinitions.contains(className);
    }

    static {
    }

    static {
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.UnknownLocationException");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.location.Location");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.location.SampleLocations");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.location.UnLocode");

        proxyClassDefinitions.add("com.aggregator.HandlingReport");
        proxyClassDefinitions.add("com.aggregator.HandlingReportErrors");
        proxyClassDefinitions.add("com.aggregator.HandlingReportErrors_Exception");
        proxyClassDefinitions.add("com.aggregator.HandlingReportService");
        proxyClassDefinitions.add("com.aggregator.HandlingReportServiceService");
        proxyClassDefinitions.add("com.aggregator.ObjectFactory");
        proxyClassDefinitions.add("com.aggregator.SubmitReport");
        proxyClassDefinitions.add("com.aggregator.SubmitReportResponse");
        proxyClassDefinitions.add("com.pathfinder.api.GraphTraversalService");
        proxyClassDefinitions.add("com.pathfinder.api.TransitEdge");
        proxyClassDefinitions.add("com.pathfinder.api.TransitPath");
        proxyClassDefinitions.add("com.pathfinder.config.PathfinderApplicationContext");
        proxyClassDefinitions.add("com.pathfinder.internal.GraphDAO");
        proxyClassDefinitions.add("com.pathfinder.internal.GraphDAOStub");
        proxyClassDefinitions.add("com.pathfinder.internal.GraphTraversalServiceImpl");
        proxyClassDefinitions.add("se.citerus.dddsample.Application");
        proxyClassDefinitions.add("se.citerus.dddsample.application.ApplicationEvents");
        proxyClassDefinitions.add("se.citerus.dddsample.application.BookingService");
        proxyClassDefinitions.add("se.citerus.dddsample.application.CargoInspectionService");
        proxyClassDefinitions.add("se.citerus.dddsample.application.HandlingEventService");
        proxyClassDefinitions.add("se.citerus.dddsample.application.impl.BookingServiceImpl");
        proxyClassDefinitions.add("se.citerus.dddsample.application.impl.CargoInspectionServiceImpl");
        proxyClassDefinitions.add("se.citerus.dddsample.application.impl.HandlingEventServiceImpl");
        proxyClassDefinitions.add("se.citerus.dddsample.application.util.DateTestUtil");
        proxyClassDefinitions.add("se.citerus.dddsample.application.util.SampleDataGenerator");
        proxyClassDefinitions.add("se.citerus.dddsample.config.DDDSampleApplicationContext");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.Cargo");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.CargoRepository");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.Delivery");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.HandlingActivity");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.Itinerary");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.Leg");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.RouteSpecification");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.RoutingStatus");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.TrackingId");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.cargo.TransportStatus");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.CannotCreateHandlingEventException");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.HandlingEvent");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.HandlingEventFactory");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.HandlingEventRepository");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.HandlingHistory");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.UnknownCargoException");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.handling.UnknownVoyageException");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.location.LocationRepository");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.voyage.CarrierMovement");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.voyage.SampleVoyages");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.voyage.Schedule");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.voyage.Voyage");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.voyage.VoyageNumber");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.model.voyage.VoyageRepository");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.service.RoutingService");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.AbstractSpecification");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.AndSpecification");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.DomainEvent");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.DomainObjectUtils");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.Entity");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.NotSpecification");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.OrSpecification");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.Specification");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.ValueObject");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.experimental.DomainEvent");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.experimental.Entity");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.experimental.ValueObject");
        proxyClassDefinitions.add("se.citerus.dddsample.domain.shared.experimental.ValueObjectSupport");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.messaging.jms.CargoHandledConsumer");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.messaging.jms.HandlingEventRegistrationAttemptConsumer");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.messaging.jms.JmsApplicationEventsImpl");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.messaging.jms.SimpleLoggingConsumer");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.persistence.hibernate.CargoRepositoryHibernate");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.persistence.hibernate.HandlingEventRepositoryHibernate");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.persistence.hibernate.HibernateRepository");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.persistence.hibernate.LocationRepositoryHibernate");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.persistence.hibernate.VoyageRepositoryHibernate");
        proxyClassDefinitions.add("se.citerus.dddsample.infrastructure.routing.ExternalRoutingService");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.BookingServiceFacade");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.dto.CargoRoutingDTO");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.dto.LegDTO");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.dto.LocationDTO");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.dto.RouteCandidateDTO");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.internal.BookingServiceFacadeImpl");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.internal.assembler.CargoRoutingDTOAssembler");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.internal.assembler.ItineraryCandidateDTOAssembler");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.facade.internal.assembler.LocationDTOAssembler");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.web.BookingDispatcherServlet");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.web.CargoAdminController");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.web.RegistrationCommand");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.booking.web.RouteAssignmentCommand");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.handling.HandlingEventRegistrationAttempt");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.handling.HandlingReportParser");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.handling.file.UploadDirectoryScanner");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.handling.ws.HandlingReportServiceImpl");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.tracking.CargoTrackingController");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.tracking.CargoTrackingViewAdapter");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.tracking.TrackCommand");
        proxyClassDefinitions.add("se.citerus.dddsample.interfaces.tracking.TrackCommandValidator");
    }
}