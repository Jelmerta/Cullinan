package util;

import java.util.Objects;

public class CullinanId {
    private String idValue;

    public CullinanId(String idValue) {
        this.idValue = idValue;
    }

    public String getIdValue() {
        return idValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CullinanId that = (CullinanId) o;
        return Objects.equals(idValue, that.idValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idValue);
    }

    // Satisfy Hibernate... Really required?
    CullinanId() {
    }
}