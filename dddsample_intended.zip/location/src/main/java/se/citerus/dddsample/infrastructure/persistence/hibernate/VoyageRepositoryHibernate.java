package se.citerus.dddsample.infrastructure.persistence.hibernate;
import se.citerus.dddsample.domain.model.voyage.Voyage;
import se.citerus.dddsample.domain.model.voyage.VoyageNumber;
import se.citerus.dddsample.domain.model.voyage.VoyageRepository;
import org.springframework.stereotype.Repository;
/**
 * Hibernate implementation of CarrierMovementRepository.
 */
@Repository
public class VoyageRepositoryHibernate extends HibernateRepository implements VoyageRepository {
    public Voyage find(final VoyageNumber voyageNumber) {
        throw new IllegalStateException();
    }
}