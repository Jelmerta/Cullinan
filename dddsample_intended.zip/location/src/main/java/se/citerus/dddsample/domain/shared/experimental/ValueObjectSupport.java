package se.citerus.dddsample.domain.shared.experimental;
import se.citerus.dddsample.domain.shared.ValueObject;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
/**
 * Base class for value objects.
 *
 * @param <T>
 */
public abstract class ValueObjectSupport<T extends ValueObject<T>> implements ValueObject<T> {
    private transient int cachedHashCode = 0;

    /**
     *
     * @param other
     * 		The other value object.
     * @return True if all non-transient fields are equal.
     */
    @Override
    public final boolean sameValueAs(final T other) {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Hash code built from all non-transient fields.
     */
    @Override
    public final int hashCode() {
        throw new IllegalStateException();
    }

    /**
     *
     * @param o
     * 		other object
     * @return True if other object has the same value as this value object.
     */
    @Override
    public final boolean equals(final Object o) {
        throw new IllegalStateException();
    }
}