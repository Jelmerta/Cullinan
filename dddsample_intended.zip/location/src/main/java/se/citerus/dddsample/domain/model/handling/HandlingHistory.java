package se.citerus.dddsample.domain.model.handling;
import java.util.*;
import se.citerus.dddsample.domain.shared.ValueObject;
import org.apache.commons.lang.Validate;
/**
 * The handling history of a cargo.
 */
public class HandlingHistory implements ValueObject<HandlingHistory> {
    private final List<HandlingEvent> handlingEvents;

    public static final HandlingHistory EMPTY = new HandlingHistory(Collections.<HandlingEvent>emptyList());

    public HandlingHistory(Collection<HandlingEvent> handlingEvents) {
        Validate.notNull(handlingEvents, "Handling events are required");
        this.handlingEvents = new ArrayList<>(handlingEvents);
    }

    /**
     *
     * @return A distinct list (no duplicate registrations) of handling events, ordered by completion time.
     */
    public List<HandlingEvent> distinctEventsByCompletionTime() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Most recently completed event, or null if the delivery history is empty.
     */
    public HandlingEvent mostRecentlyCompletedEvent() {
        throw new IllegalStateException();
    }

    @Override
    public boolean sameValueAs(HandlingHistory other) {
        throw new IllegalStateException();
    }

    @Override
    public boolean equals(Object o) {
        throw new IllegalStateException();
    }

    @Override
    public int hashCode() {
        throw new IllegalStateException();
    }

    private static final Comparator<HandlingEvent> BY_COMPLETION_TIME_COMPARATOR = (he1, he2) -> he1.completionTime().compareTo(he2.completionTime());
}