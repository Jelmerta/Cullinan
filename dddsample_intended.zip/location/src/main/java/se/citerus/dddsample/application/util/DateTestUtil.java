package se.citerus.dddsample.application.util;
import java.util.Date;
/**
 * A few utils for working with Date in tests.
 */
public final class DateTestUtil {
    /**
     *
     * @param date
     * 		date string as yyyy-MM-dd
     * @return Date representation
     */
    public static Date toDate(final String date) {
        throw new IllegalStateException();
    }

    /**
     *
     * @param date
     * 		date string as yyyy-MM-dd
     * @param time
     * 		time string as HH:mm
     * @return Date representation
     */
    public static Date toDate(final String date, final String time) {
        throw new IllegalStateException();
    }

    /**
     * Prevent instantiation.
     */
    private DateTestUtil() {
    }
}