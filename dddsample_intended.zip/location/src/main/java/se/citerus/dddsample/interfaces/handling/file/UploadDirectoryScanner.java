package se.citerus.dddsample.interfaces.handling.file;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.TimerTask;
import se.citerus.dddsample.application.ApplicationEvents;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
/**
 * Periodically scans a certain directory for files and attempts
 * to parse handling event registrations from the contents.
 * <p/>
 * Files that fail to parse are moved into a separate directory,
 * succesful files are deleted.
 */
public class UploadDirectoryScanner extends TimerTask implements InitializingBean {
    private File uploadDirectory;

    private File parseFailureDirectory;

    private static final Log logger = LogFactory.getLog(UploadDirectoryScanner.class);

    private ApplicationEvents applicationEvents;

    @Override
    public void run() {
        throw new IllegalStateException();
    }

    private void parse(final File file) throws IOException {
        throw new IllegalStateException();
    }

    private String toRejectedFilename(final File file) {
        throw new IllegalStateException();
    }

    private void writeRejectedLinesToFile(final String filename, final List<String> rejectedLines) throws IOException {
        throw new IllegalStateException();
    }

    private void parseLine(final String line) throws Exception {
        throw new IllegalStateException();
    }

    private void queueAttempt(String completionTimeStr, String trackingIdStr, String voyageNumberStr, String unLocodeStr, String eventTypeStr) throws Exception {
        throw new IllegalStateException();
    }

    private void delete(final File file) {
        throw new IllegalStateException();
    }

    private void move(final File file) {
        throw new IllegalStateException();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        throw new IllegalStateException();
    }

    public void setUploadDirectory(File uploadDirectory) {
        throw new IllegalStateException();
    }

    public void setParseFailureDirectory(File parseFailureDirectory) {
        throw new IllegalStateException();
    }

    public void setApplicationEvents(ApplicationEvents applicationEvents) {
        throw new IllegalStateException();
    }
}