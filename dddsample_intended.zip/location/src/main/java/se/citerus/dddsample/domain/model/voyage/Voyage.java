package se.citerus.dddsample.domain.model.voyage;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.domain.shared.Entity;
import org.apache.commons.lang.Validate;
/**
 * A Voyage.
 */
public class Voyage implements Entity<Voyage> {
    private VoyageNumber voyageNumber;

    private Schedule schedule;

    // Null object pattern
    public static final Voyage NONE = new Voyage(new VoyageNumber(""), Schedule.EMPTY);

    public Voyage(final VoyageNumber voyageNumber, final Schedule schedule) {
        Validate.notNull(voyageNumber, "Voyage number is required");
        Validate.notNull(schedule, "Schedule is required");
        this.voyageNumber = voyageNumber;
        this.schedule = schedule;
    }

    /**
     *
     * @return Voyage number.
     */
    public VoyageNumber voyageNumber() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Schedule.
     */
    public Schedule schedule() {
        throw new IllegalStateException();
    }

    @Override
    public int hashCode() {
        throw new IllegalStateException();
    }

    @Override
    public boolean equals(Object o) {
        throw new IllegalStateException();
    }

    @Override
    public boolean sameIdentityAs(Voyage other) {
        throw new IllegalStateException();
    }

    @Override
    public String toString() {
        throw new IllegalStateException();
    }

    Voyage() {
        // Needed by Hibernate
    }

    // Needed by Hibernate
    private Long id;

    /**
     * Builder pattern is used for incremental construction
     * of a Voyage aggregate. This serves as an aggregate factory.
     */
    public static final class Builder {
        private final List<CarrierMovement> carrierMovements = new ArrayList<CarrierMovement>();

        private final VoyageNumber voyageNumber;

        private Location departureLocation;

        public Builder(final VoyageNumber voyageNumber, final Location departureLocation) {
            Validate.notNull(voyageNumber, "Voyage number is required");
            Validate.notNull(departureLocation, "Departure location is required");
            this.voyageNumber = voyageNumber;
            this.departureLocation = departureLocation;
        }

        public Builder addMovement(Location arrivalLocation, Date departureTime, Date arrivalTime) {
            carrierMovements.add(new CarrierMovement(departureLocation, arrivalLocation, departureTime, arrivalTime));
            // Next departure location is the same as this arrival location
            this.departureLocation = arrivalLocation;
            return this;
        }

        public Voyage build() {
            return new Voyage(voyageNumber, new Schedule(carrierMovements));
        }
    }
}