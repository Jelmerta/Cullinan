package se.citerus.dddsample;
import com.pathfinder.config.PathfinderApplicationContext;
import javax.annotation.PostConstruct;
import se.citerus.dddsample.application.util.SampleDataGenerator;
import se.citerus.dddsample.config.DDDSampleApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
@Configuration
@Import({ DDDSampleApplicationContext.class, PathfinderApplicationContext.class })
@EnableAutoConfiguration
public class Application {
    @Autowired
    SampleDataGenerator sampleDataGenerator;

    @PostConstruct
    public void init() {
        throw new IllegalStateException();
    }

    public static void main(String[] args) throws Exception {
        throw new IllegalStateException();
    }
}