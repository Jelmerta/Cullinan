package se.citerus.dddsample.domain.model.voyage;
import se.citerus.dddsample.domain.shared.ValueObject;
import org.apache.commons.lang.Validate;
/**
 * Identifies a voyage.
 */
public class VoyageNumber implements ValueObject<VoyageNumber> {
    private String number;

    public VoyageNumber(String number) {
        Validate.notNull(number);
        this.number = number;
    }

    @Override
    public boolean equals(Object o) {
        throw new IllegalStateException();
    }

    @Override
    public int hashCode() {
        throw new IllegalStateException();
    }

    @Override
    public boolean sameValueAs(VoyageNumber other) {
        throw new IllegalStateException();
    }

    @Override
    public String toString() {
        throw new IllegalStateException();
    }

    public String idString() {
        throw new IllegalStateException();
    }

    VoyageNumber() {
        // Needed by Hibernate
    }
}