package se.citerus.dddsample.interfaces.booking.web;
import java.util.Map;
import se.citerus.dddsample.interfaces.booking.facade.BookingServiceFacade;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 * Handles cargo booking and routing. Operates against a dedicated remoting service facade,
 * and could easily be rewritten as a thick Swing client. Completely separated from the domain layer,
 * unlike the tracking user interface.
 * <p>
 * In order to successfully keep the domain model shielded from user interface considerations,
 * this approach is generally preferred to the one taken in the tracking controller. However,
 * there is never any one perfect solution for all situations, so we've chosen to demonstrate
 * two polarized ways to build user interfaces.
 *
 * @see se.citerus.dddsample.interfaces.tracking.CargoTrackingController
 */
@Controller
@RequestMapping("/admin")
public final class CargoAdminController {
    private BookingServiceFacade bookingServiceFacade;

    @InitBinder
    protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping("/registration")
    public String registration(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public void register(HttpServletRequest request, HttpServletResponse response, RegistrationCommand command) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping("/list")
    public String list(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping("/show")
    public String show(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping("/selectItinerary")
    public String selectItinerary(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping(value = "/assignItinerary", method = RequestMethod.POST)
    public void assignItinerary(HttpServletRequest request, HttpServletResponse response, RouteAssignmentCommand command) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping("/pickNewDestination")
    public String pickNewDestination(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
        throw new IllegalStateException();
    }

    @RequestMapping(value = "/changeDestination", method = RequestMethod.POST)
    public void changeDestination(HttpServletRequest request, HttpServletResponse response) throws Exception {
        throw new IllegalStateException();
    }

    public void setBookingServiceFacade(BookingServiceFacade bookingServiceFacade) {
        throw new IllegalStateException();
    }
}