package se.citerus.dddsample.domain.model.location;

import util.SerializationUtil;
import util.StorageManager;

import java.rmi.RemoteException;
import java.util.List;
import java.util.stream.Collectors;

public class LocationManager {
    public static String unLocode(String objectReference) throws RemoteException {
        Location objectReferenceObject = ((Location) (SerializationUtil.decode(objectReference)));
        UnLocode result = objectReferenceObject.unLocode();
        return SerializationUtil.encode(result);
    }

    public static String name(String objectReference) throws RemoteException {
        Location objectReferenceObject = ((Location) (SerializationUtil.decode(objectReference)));
        return objectReferenceObject.name();
    }

    public static boolean equals(String objectReference, final String object) throws RemoteException {
        Location objectReferenceObject = ((Location) (SerializationUtil.decode(objectReference)));
        Object objectInstance = SerializationUtil.decode(object);
        return objectReferenceObject.equals(objectInstance);
    }

    public static boolean sameIdentityAs(String objectReference, final String other) {
        Location objectReferenceObject = ((Location) (SerializationUtil.decode(objectReference)));
        Location otherInstance = ((Location) (SerializationUtil.decode(other)));
        return objectReferenceObject.sameIdentityAs(otherInstance);
    }

    public static int hashCode(String objectReference) throws RemoteException {
        Location objectReferenceObject = ((Location) (SerializationUtil.decode(objectReference)));
        return objectReferenceObject.hashCode();
    }

    public static String toString(String objectReference) throws RemoteException {
        Location objectReferenceObject = ((Location) (SerializationUtil.decode(objectReference)));
        return objectReferenceObject.toString();
    }

    // Only used to satisfy Hibernate. Could throw an IllegalStateException for example if we wanted.
    public static Location newLocation() {
        Location newObject = new Location();
        StorageManager.add(newObject);
        return newObject;
    }

    public static Location newLocation(UnLocode unLocode, final String name) {
        Location newObject = new Location(unLocode, name);
        StorageManager.add(newObject);
        return newObject;
    }

    // TODO This kind of method kind of shows that a storage for each class is kind of nicer... Like having separate tables... Not a necessity
    // Method manually added: Database query that cannot automatically be detected.
    public static List<String> findAll() {
        return StorageManager.getStorage().values().stream()
                .filter(object -> object.getClass().equals(Location.class))
                .map(loc -> ((Location) loc).getReferenceId().getIdValue())
                .collect(Collectors.toList());
    }
}
