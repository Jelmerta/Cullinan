package se.citerus.dddsample.infrastructure.routing;
import com.pathfinder.api.GraphTraversalService;
import com.pathfinder.api.TransitEdge;
import com.pathfinder.api.TransitPath;
import java.util.List;
import se.citerus.dddsample.domain.model.cargo.Itinerary;
import se.citerus.dddsample.domain.model.cargo.Leg;
import se.citerus.dddsample.domain.model.cargo.RouteSpecification;
import se.citerus.dddsample.domain.model.location.LocationRepository;
import se.citerus.dddsample.domain.model.voyage.VoyageRepository;
import se.citerus.dddsample.domain.service.RoutingService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/**
 * Our end of the routing service. This is basically a data model
 * translation layer between our domain model and the API put forward
 * by the routing team, which operates in a different context from us.
 */
public class ExternalRoutingService implements RoutingService {
    private GraphTraversalService graphTraversalService;

    private LocationRepository locationRepository;

    private VoyageRepository voyageRepository;

    private static final Log log = LogFactory.getLog(ExternalRoutingService.class);

    public List<Itinerary> fetchRoutesForSpecification(RouteSpecification routeSpecification) {
        throw new IllegalStateException();
    }

    private Itinerary toItinerary(TransitPath transitPath) {
        throw new IllegalStateException();
    }

    private Leg toLeg(TransitEdge edge) {
        throw new IllegalStateException();
    }

    public void setGraphTraversalService(GraphTraversalService graphTraversalService) {
        throw new IllegalStateException();
    }

    public void setLocationRepository(LocationRepository locationRepository) {
        throw new IllegalStateException();
    }

    public void setVoyageRepository(VoyageRepository voyageRepository) {
        throw new IllegalStateException();
    }
}