package se.citerus.dddsample.domain.model.location;
import client.rmiinterface.SampleLocationsInterface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import util.CullinanId;
import util.SerializationUtil;
import util.StorageManager;
public class SampleLocationsServiceImplementation extends UnicastRemoteObject implements SampleLocationsInterface {
    public SampleLocationsServiceImplementation() throws RemoteException {
    }

    @Override
    public String newSampleLocations() {
        SampleLocations newObject = new SampleLocations();
        CullinanId id = StorageManager.add(newObject);
        return id.getIdValue();
    }

    // We could get away with just having this call once for a service...
    @Override
    public String getConstant(String constantName) {
        Object constant = SampleLocations.getConstant(constantName);
        return SerializationUtil.encode(constant);
    }
}