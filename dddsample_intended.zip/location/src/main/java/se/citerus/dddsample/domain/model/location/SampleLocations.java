package se.citerus.dddsample.domain.model.location;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import util.CullinanId;
import util.CullinanReference;
import util.StorageManager;

/**
 * Sample locations, for test purposes.
 */
// TODO How do we deal with monolith starting multiple times, creating new objects, referring to different ids? Should we test already existing location and unlocode and then return this id instead?
public class SampleLocations implements CullinanReference {

    // TODO Should it be in storage? They are named though. Duplicates? Were they originally also duplicates?
    // TODO How do we add the reference ids? Added in implementation... We can set them manually but how do we match them with monolith?

    // TODO We handle constants with id used outside differently... Probably a manual conversion?


    // What if two places in the monolith both refer to a constant?
    // They would both use the same constant in the original
    // But if two different services start refering to the constant it might be duplicated...
    // What if we define the constant here instead of in the StorageManager, would we get away with that?
    // We would still need to store the values then though.
    // Still feels easier to store them here instead of adding them in the StorageManager

//    public static final Location HONGKONG = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::3")); // TODO Maybe just retrieve by predefined id?
    // TODO Does it matter if we split the locations. Some in StorageManager some just static memory?
    // Something like a find call will not find the static values...?

    // TODO Should these be in the manager or here...?

    // TODO Maybe we can document how we would manage a database automatically, and if we can already work towards this
    // This is currently the way for database initialized objects to be created, as we want them to have specific ids.
    // It is currently a manual action to move the automated constants to a database variant.
    public static final Location HONGKONG = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::3"));
    public static final Location MELBOURNE = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::2"));
    public static final Location STOCKHOLM = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::1"));
    public static final Location HELSINKI = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::5"));
    public static final Location CHICAGO = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::7"));
    public static final Location TOKYO = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::4"));
    public static final Location HAMBURG = (Location) StorageManager.get(new CullinanId("se.citerus.dddsample.domain.model.location.Location::6"));

    // This is the normal way to add constants
    public static final Location SHANGHAI = LocationManager.newLocation(UnLocodeManager.newUnLocode("CNSHA"), "Shanghai");
    public static final Location ROTTERDAM = LocationManager.newLocation(UnLocodeManager.newUnLocode("NLRTM"), "Rotterdam");
    public static final Location GOTHENBURG = LocationManager.newLocation(UnLocodeManager.newUnLocode("SEGOT"), "Göteborg");
    public static final Location HANGZOU = LocationManager.newLocation(UnLocodeManager.newUnLocode("CNHGH"), "Hangzhou");
    public static final Location NEWYORK = LocationManager.newLocation(UnLocodeManager.newUnLocode("USNYC"), "New York");
    public static final Location DALLAS = LocationManager.newLocation(UnLocodeManager.newUnLocode("USDAL"), "Dallas");
    public static final Location UNKNOWN = LocationManager.newLocation(UnLocodeManager.newUnLocode("XXXXX"), "Unknown location"); // Originally in Location...

    private static final Map<String, Object> constants = new HashMap<>();
    static {
        constants.put("HONGKONG", HONGKONG);
        constants.put("MELBOURNE", MELBOURNE);
        constants.put("STOCKHOLM", STOCKHOLM);
        constants.put("HELSINKI", HELSINKI);
        constants.put("CHICAGO", CHICAGO);
        constants.put("TOKYO", TOKYO);
        constants.put("HAMBURG", HAMBURG);
        constants.put("SHANGHAI", SHANGHAI);
        constants.put("ROTTERDAM", ROTTERDAM);
        constants.put("GOTHENBURG", GOTHENBURG);
        constants.put("HANGZOU", HANGZOU);
        constants.put("NEWYORK", NEWYORK);
        constants.put("DALLAS", DALLAS);
        constants.put("UNKNOWN", UNKNOWN);
    }

    public static Object getConstant(String constantName) {
        Object constant = constants.get(constantName);
        if (constant == null) {
            throw new IllegalArgumentException("Constant with name " + constantName + " doesn't exist");
        }
        return constant;
    }

    public static final Map<UnLocode, Location> ALL = new HashMap<UnLocode, Location>();

    static {
        for (Field field : SampleLocations.class.getDeclaredFields()) {
            if (field.getType().equals(Location.class)) {
                try {
                    Location location = ((Location) (field.get(null)));
                    ALL.put(location.unLocode(), location);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static List<Location> getAll() {
        return new ArrayList<Location>(ALL.values());
    }

    public static Location lookup(UnLocode unLocode) {
        return ALL.get(unLocode);
    }

    private CullinanId referenceId;

    public CullinanId getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(CullinanId referenceId) {
        this.referenceId = referenceId;
    }
}