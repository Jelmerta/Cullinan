package se.citerus.dddsample.infrastructure.messaging.jms;
import se.citerus.dddsample.application.HandlingEventService;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/**
 * Consumes handling event registration attempt messages and delegates to
 * proper registration.
 */
public class HandlingEventRegistrationAttemptConsumer implements MessageListener {
    private HandlingEventService handlingEventService;

    private static final Log logger = LogFactory.getLog(HandlingEventRegistrationAttemptConsumer.class);

    @Override
    public void onMessage(final Message message) {
        throw new IllegalStateException();
    }

    public void setHandlingEventService(HandlingEventService handlingEventService) {
        throw new IllegalStateException();
    }
}