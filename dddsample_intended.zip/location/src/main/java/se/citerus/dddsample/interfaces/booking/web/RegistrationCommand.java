package se.citerus.dddsample.interfaces.booking.web;
/**
 */
public final class RegistrationCommand {
    private String originUnlocode;

    private String destinationUnlocode;

    private String arrivalDeadline;

    public String getOriginUnlocode() {
        throw new IllegalStateException();
    }

    public void setOriginUnlocode(final String originUnlocode) {
        throw new IllegalStateException();
    }

    public String getDestinationUnlocode() {
        throw new IllegalStateException();
    }

    public void setDestinationUnlocode(final String destinationUnlocode) {
        throw new IllegalStateException();
    }

    public String getArrivalDeadline() {
        throw new IllegalStateException();
    }

    public void setArrivalDeadline(String arrivalDeadline) {
        throw new IllegalStateException();
    }
}