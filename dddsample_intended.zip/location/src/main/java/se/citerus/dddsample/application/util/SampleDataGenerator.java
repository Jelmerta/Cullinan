package se.citerus.dddsample.application.util;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import se.citerus.dddsample.domain.model.cargo.*;
import se.citerus.dddsample.domain.model.handling.*;
import se.citerus.dddsample.domain.model.location.LocationRepository;
import se.citerus.dddsample.domain.model.voyage.VoyageRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;
import static java.util.Objects.requireNonNull;
/**
 * Provides sample data.
 */
public class SampleDataGenerator {
    private static final Timestamp base;

    static {
        try {
            Date date = new SimpleDateFormat("yyyy-MM-dd").parse("2008-01-01");
            base = new Timestamp(date.getTime() - ((((1000L * 60) * 60) * 24) * 100));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    private final PlatformTransactionManager transactionManager;

    private final SessionFactory sf;

    private final CargoRepository cargoRepository;

    private final VoyageRepository voyageRepository;

    private final LocationRepository locationRepository;

    private final HandlingEventRepository handlingEventRepository;

    public SampleDataGenerator(PlatformTransactionManager transactionManager, SessionFactory sf, CargoRepository cargoRepository, VoyageRepository voyageRepository, LocationRepository locationRepository, HandlingEventRepository handlingEventRepository) {
        this.transactionManager = requireNonNull(transactionManager);
        this.sf = requireNonNull(sf);
        this.cargoRepository = requireNonNull(cargoRepository);
        this.voyageRepository = requireNonNull(voyageRepository);
        this.locationRepository = requireNonNull(locationRepository);
        this.handlingEventRepository = requireNonNull(handlingEventRepository);
    }

    private static void loadHandlingEventData(JdbcTemplate jdbcTemplate) {
        throw new IllegalStateException();
    }

    private static void loadCarrierMovementData(JdbcTemplate jdbcTemplate) {
        throw new IllegalStateException();
    }

    private static void loadCargoData(JdbcTemplate jdbcTemplate) {
        throw new IllegalStateException();
    }

    private static void loadLocationData(JdbcTemplate jdbcTemplate) {
        throw new IllegalStateException();
    }

    private static void loadItineraryData(JdbcTemplate jdbcTemplate) {
        throw new IllegalStateException();
    }

    public void generate() {
        throw new IllegalStateException();
    }

    public static void loadHibernateData(TransactionTemplate tt, final SessionFactory sf, final HandlingEventFactory handlingEventFactory, final HandlingEventRepository handlingEventRepository) {
        throw new IllegalStateException();
    }

    public static void loadSampleData(final JdbcTemplate jdbcTemplate, TransactionTemplate transactionTemplate) {
        throw new IllegalStateException();
    }

    private static void executeUpdate(JdbcTemplate jdbcTemplate, String sql, Object[][] args) {
        throw new IllegalStateException();
    }

    private static Timestamp ts(int hours) {
        throw new IllegalStateException();
    }

    public static Date offset(int hours) {
        throw new IllegalStateException();
    }
}