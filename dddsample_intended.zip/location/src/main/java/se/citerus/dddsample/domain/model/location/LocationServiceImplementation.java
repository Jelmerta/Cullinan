package se.citerus.dddsample.domain.model.location;
import client.rmiinterface.LocationInterface;
import util.SerializationUtil;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

public class LocationServiceImplementation extends UnicastRemoteObject implements LocationInterface {
    @Override
    public String unLocode(String objectReference) throws RemoteException {
        return LocationManager.unLocode(objectReference);
    }

    @Override
    public String name(String objectReference) throws RemoteException {
        return LocationManager.name(objectReference);
    }

    @Override
    public boolean equals(String objectReference, final String object) throws RemoteException {
        return LocationManager.equals(objectReference, object);
    }

    @Override
    public boolean sameIdentityAs(String objectReference, final String other) throws RemoteException {
        return LocationManager.sameIdentityAs(objectReference, other);
    }

    @Override
    public int hashCode(String objectReference) throws RemoteException {
        return LocationManager.hashCode(objectReference);
    }

    @Override
    public String toString(String objectReference) throws RemoteException {
        return LocationManager.toString(objectReference);
    }

    public LocationServiceImplementation() throws RemoteException {
    }

    @Override
    public String newLocation() {
        return LocationManager.newLocation().getReferenceId().getIdValue();
    }

    @Override
    public String newLocation(String unLocodeReferenceId, final String name) {
        UnLocode unLocodeReferenceIdObject = ((UnLocode) (SerializationUtil.decode(unLocodeReferenceId)));
        return LocationManager.newLocation(unLocodeReferenceIdObject, name).getReferenceId().getIdValue();
    }

    @Override
    public List<String> findAll() throws RemoteException {
        return LocationManager.findAll();
    }
}