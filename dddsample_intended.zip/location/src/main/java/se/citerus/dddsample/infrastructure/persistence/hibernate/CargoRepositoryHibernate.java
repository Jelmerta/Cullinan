package se.citerus.dddsample.infrastructure.persistence.hibernate;
import java.util.List;
import se.citerus.dddsample.domain.model.cargo.Cargo;
import se.citerus.dddsample.domain.model.cargo.CargoRepository;
import se.citerus.dddsample.domain.model.cargo.TrackingId;
import org.springframework.stereotype.Repository;
/**
 * Hibernate implementation of CargoRepository.
 */
@Repository
public class CargoRepositoryHibernate extends HibernateRepository implements CargoRepository {
    public Cargo find(TrackingId tid) {
        throw new IllegalStateException();
    }

    public void store(Cargo cargo) {
        throw new IllegalStateException();
    }

    public TrackingId nextTrackingId() {
        throw new IllegalStateException();
    }

    public List<Cargo> findAll() {
        throw new IllegalStateException();
    }
}