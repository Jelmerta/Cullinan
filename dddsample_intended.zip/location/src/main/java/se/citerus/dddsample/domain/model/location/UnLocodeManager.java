package se.citerus.dddsample.domain.model.location;

import util.CullinanId;
import util.SerializationUtil;
import util.StorageManager;

import java.rmi.RemoteException;
import java.util.HashMap;

public class UnLocodeManager {
    public static UnLocode newUnLocode() {
        throw new IllegalStateException("Constructor should not be used"); // TODO Hard to detect automatically as it is called by Hibernate
    }

    public static UnLocode newUnLocode(final String countryAndLocation) {
        // This is manually added code to deal with duplicates
        UnLocode unLocode = findExistingUnLocode(countryAndLocation);
        if (unLocode != null) {
//            throw new IllegalStateException("UnLocode already exists."); // TODO This should be a databse error right? This is like the uniqueness constraint in the hibernate scheme... When calling new in the original this however does not mean it is stored in the database. Several occasions where the same unlocode is created, so suppose we just want to return an existing one if there is one.
            return unLocode;
        }

        UnLocode newObject = new UnLocode(countryAndLocation);
        StorageManager.add(newObject);
        return newObject;
    }

    public static String idString(String objectReference) {
        UnLocode objectReferenceObject = ((UnLocode) (SerializationUtil.decode(objectReference)));
        return objectReferenceObject.idString();
    }

    public static boolean equals(String objectReference, final String o) throws RemoteException {
        UnLocode objectReferenceObject = ((UnLocode) (SerializationUtil.decode(objectReference)));
        Object oInstance = SerializationUtil.decode(o);
        return objectReferenceObject.equals(oInstance);
    }

    public static int hashCode(String objectReference) throws RemoteException {
        UnLocode objectReferenceObject = ((UnLocode) (SerializationUtil.decode(objectReference)));
        return objectReferenceObject.hashCode();
    }

    public static boolean sameValueAs(String objectReference, String other) throws RemoteException {
        UnLocode objectReferenceObject = ((UnLocode) (SerializationUtil.decode(objectReference)));
        UnLocode otherInstance = ((UnLocode) (SerializationUtil.decode(other)));
        return objectReferenceObject.sameValueAs(otherInstance);
    }

    public static String toString(String objectReference) throws RemoteException {
        UnLocode objectReferenceObject = ((UnLocode) (SerializationUtil.decode(objectReference)));
        return objectReferenceObject.toString();
    }

    public static String findLocation(String referenceId) {
        HashMap<CullinanId, Object> storage = StorageManager.getStorage();
        // Have to go over the values of the storage was we are looking for a location matching an unlocode id
        for (Object object : storage.values()) {
            if (object.getClass() == Location.class) {
                Location location = (Location) object;

                if (location.unLocode().getReferenceId().equals(new CullinanId(referenceId))) {
                    return SerializationUtil.encode(location);
                }
            }
        }
        return null;
    }

    private static UnLocode findExistingUnLocode(String countryAndLocation) {
        UnLocode unLocodeNew = new UnLocode(countryAndLocation);

        HashMap<CullinanId, Object> storage = StorageManager.getStorage();
        for (Object object : storage.values()) {
            if (object.getClass() == UnLocode.class) {
                UnLocode unLocode = (UnLocode) object;

                if (unLocode.equals(unLocodeNew)) { // Only checks content being equal, not the reference id
                    return unLocode;
                }
            }
        }
        return null;
    }
}
