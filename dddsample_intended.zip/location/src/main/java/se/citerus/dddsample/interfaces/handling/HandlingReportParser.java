package se.citerus.dddsample.interfaces.handling;
import com.aggregator.HandlingReport;
import java.util.Date;
import java.util.List;
import se.citerus.dddsample.domain.model.cargo.TrackingId;
import se.citerus.dddsample.domain.model.handling.HandlingEvent;
import se.citerus.dddsample.domain.model.location.UnLocode;
import se.citerus.dddsample.domain.model.voyage.VoyageNumber;
import org.apache.commons.lang.StringUtils;
/**
 * Utility methods for parsing various forms of handling report formats.
 *
 * Supports the notification pattern for incremental error reporting.
 */
public class HandlingReportParser {
    public static final String ISO_8601_FORMAT = "yyyy-MM-dd HH:mm";

    public static UnLocode parseUnLocode(final String unlocode, final List<String> errors) {
        throw new IllegalStateException();
    }

    public static TrackingId parseTrackingId(final String trackingId, final List<String> errors) {
        throw new IllegalStateException();
    }

    public static VoyageNumber parseVoyageNumber(final String voyageNumber, final List<String> errors) {
        throw new IllegalStateException();
    }

    public static Date parseDate(final String completionTime, final List<String> errors) {
        throw new IllegalStateException();
    }

    public static HandlingEvent.Type parseEventType(final String eventType, final List<String> errors) {
        throw new IllegalStateException();
    }

    public static Date parseCompletionTime(HandlingReport handlingReport, List<String> errors) {
        throw new IllegalStateException();
    }
}