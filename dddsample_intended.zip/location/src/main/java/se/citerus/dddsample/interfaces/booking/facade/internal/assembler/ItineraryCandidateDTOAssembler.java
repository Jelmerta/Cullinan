package se.citerus.dddsample.interfaces.booking.facade.internal.assembler;
import se.citerus.dddsample.domain.model.cargo.Itinerary;
import se.citerus.dddsample.domain.model.cargo.Leg;
import se.citerus.dddsample.domain.model.location.LocationRepository;
import se.citerus.dddsample.domain.model.voyage.VoyageRepository;
import se.citerus.dddsample.interfaces.booking.facade.dto.LegDTO;
import se.citerus.dddsample.interfaces.booking.facade.dto.RouteCandidateDTO;
/**
 * Assembler class for the ItineraryCandidateDTO.
 */
public class ItineraryCandidateDTOAssembler {
    /**
     *
     * @param itinerary
     * 		itinerary
     * @return A route candidate DTO
     */
    public RouteCandidateDTO toDTO(final Itinerary itinerary) {
        throw new IllegalStateException();
    }

    /**
     *
     * @param leg
     * 		leg
     * @return A leg DTO
     */
    protected LegDTO toLegDTO(final Leg leg) {
        throw new IllegalStateException();
    }

    /**
     *
     * @param routeCandidateDTO
     * 		route candidate DTO
     * @param voyageRepository
     * 		voyage repository
     * @param locationRepository
     * 		location repository
     * @return An itinerary
     */
    public Itinerary fromDTO(final RouteCandidateDTO routeCandidateDTO, final VoyageRepository voyageRepository, final LocationRepository locationRepository) {
        throw new IllegalStateException();
    }
}