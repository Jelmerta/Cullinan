package se.citerus.dddsample.infrastructure.messaging.jms;
import se.citerus.dddsample.application.ApplicationEvents;
import se.citerus.dddsample.domain.model.cargo.Cargo;
import se.citerus.dddsample.domain.model.handling.HandlingEvent;
import se.citerus.dddsample.interfaces.handling.HandlingEventRegistrationAttempt;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.MessageCreator;
/**
 * JMS based implementation.
 */
public final class JmsApplicationEventsImpl implements ApplicationEvents {
    private JmsOperations jmsOperations;

    private Destination cargoHandledQueue;

    private Destination misdirectedCargoQueue;

    private Destination deliveredCargoQueue;

    private Destination rejectedRegistrationAttemptsQueue;

    private Destination handlingEventQueue;

    private static final Log logger = LogFactory.getLog(JmsApplicationEventsImpl.class);

    @Override
    public void cargoWasHandled(final HandlingEvent event) {
        throw new IllegalStateException();
    }

    @Override
    public void cargoWasMisdirected(final Cargo cargo) {
        throw new IllegalStateException();
    }

    @Override
    public void cargoHasArrived(final Cargo cargo) {
        throw new IllegalStateException();
    }

    @Override
    public void receivedHandlingEventRegistrationAttempt(final HandlingEventRegistrationAttempt attempt) {
        throw new IllegalStateException();
    }

    public void setJmsOperations(JmsOperations jmsOperations) {
        throw new IllegalStateException();
    }

    public void setCargoHandledQueue(Destination destination) {
        throw new IllegalStateException();
    }

    public void setMisdirectedCargoQueue(Destination destination) {
        throw new IllegalStateException();
    }

    public void setDeliveredCargoQueue(Destination destination) {
        throw new IllegalStateException();
    }

    public void setRejectedRegistrationAttemptsQueue(Destination destination) {
        throw new IllegalStateException();
    }

    public void setHandlingEventQueue(Destination destination) {
        throw new IllegalStateException();
    }
}