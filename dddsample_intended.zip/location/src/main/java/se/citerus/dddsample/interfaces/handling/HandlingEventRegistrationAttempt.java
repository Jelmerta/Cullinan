package se.citerus.dddsample.interfaces.handling;
import java.io.Serializable;
import java.util.Date;
import se.citerus.dddsample.domain.model.cargo.TrackingId;
import se.citerus.dddsample.domain.model.handling.HandlingEvent;
import se.citerus.dddsample.domain.model.location.UnLocode;
import se.citerus.dddsample.domain.model.voyage.VoyageNumber;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
/**
 * This is a simple transfer object for passing incoming handling event
 * registration attempts to proper the registration procedure.
 *
 * It is used as a message queue element.
 */
public final class HandlingEventRegistrationAttempt implements Serializable {
    private final Date registrationTime;

    private final Date completionTime;

    private final TrackingId trackingId;

    private final VoyageNumber voyageNumber;

    private final HandlingEvent.Type type;

    private final UnLocode unLocode;

    public HandlingEventRegistrationAttempt(final Date registrationDate, final Date completionDate, final TrackingId trackingId, final VoyageNumber voyageNumber, final HandlingEvent.Type type, final UnLocode unLocode) {
        this.registrationTime = registrationDate;
        this.completionTime = completionDate;
        this.trackingId = trackingId;
        this.voyageNumber = voyageNumber;
        this.type = type;
        this.unLocode = unLocode;
    }

    public Date getCompletionTime() {
        throw new IllegalStateException();
    }

    public TrackingId getTrackingId() {
        throw new IllegalStateException();
    }

    public VoyageNumber getVoyageNumber() {
        throw new IllegalStateException();
    }

    public HandlingEvent.Type getType() {
        throw new IllegalStateException();
    }

    public UnLocode getUnLocode() {
        throw new IllegalStateException();
    }

    public Date getRegistrationTime() {
        throw new IllegalStateException();
    }

    @Override
    public String toString() {
        throw new IllegalStateException();
    }
}