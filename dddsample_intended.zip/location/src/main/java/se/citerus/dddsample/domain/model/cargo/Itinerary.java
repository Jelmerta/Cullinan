package se.citerus.dddsample.domain.model.cargo;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import se.citerus.dddsample.domain.model.handling.HandlingEvent;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.domain.shared.ValueObject;
import org.apache.commons.lang.Validate;
/**
 * An itinerary.
 */
public class Itinerary implements ValueObject<Itinerary> {
    private List<Leg> legs = Collections.emptyList();

    static final Itinerary EMPTY_ITINERARY = new Itinerary();

    private static final Date END_OF_DAYS = new Date(Long.MAX_VALUE);

    /**
     * Constructor.
     *
     * @param legs
     * 		List of legs for this itinerary.
     */
    public Itinerary(final List<Leg> legs) {
        Validate.notEmpty(legs);
        Validate.noNullElements(legs);
        this.legs = legs;
    }

    /**
     *
     * @return the legs of this itinerary, as an <b>immutable</b> list.
     */
    public List<Leg> legs() {
        throw new IllegalStateException();
    }

    /**
     * Test if the given handling event is expected when executing this itinerary.
     *
     * @param event
     * 		Event to test.
     * @return <code>true</code> if the event is expected
     */
    public boolean isExpected(final HandlingEvent event) {
        throw new IllegalStateException();
    }

    /**
     *
     * @return The initial departure location.
     */
    Location initialDepartureLocation() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return The final arrival location.
     */
    Location finalArrivalLocation() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Date when cargo arrives at final destination.
     */
    Date finalArrivalDate() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return The last leg on the itinerary.
     */
    Leg lastLeg() {
        throw new IllegalStateException();
    }

    /**
     *
     * @param other
     * 		itinerary to compare
     * @return <code>true</code> if the legs in this and the other itinerary are all equal.
     */
    @Override
    public boolean sameValueAs(final Itinerary other) {
        throw new IllegalStateException();
    }

    @Override
    public boolean equals(final Object o) {
        throw new IllegalStateException();
    }

    @Override
    public int hashCode() {
        throw new IllegalStateException();
    }

    Itinerary() {
        // Needed by Hibernate
    }

    // Auto-generated surrogate key
    private Long id;
}