package se.citerus.dddsample.interfaces.tracking;
import org.apache.commons.lang.builder.ToStringBuilder;
import static org.apache.commons.lang.builder.ToStringStyle.MULTI_LINE_STYLE;
public final class TrackCommand {
    /**
     * The tracking id.
     */
    private String trackingId;

    public String getTrackingId() {
        throw new IllegalStateException();
    }

    public void setTrackingId(final String trackingId) {
        throw new IllegalStateException();
    }

    @Override
    public String toString() {
        throw new IllegalStateException();
    }
}