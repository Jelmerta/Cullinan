package se.citerus.dddsample.interfaces.handling.ws;
import com.aggregator.HandlingReport;
import com.aggregator.HandlingReportErrors_Exception;
import com.aggregator.HandlingReportService;
import se.citerus.dddsample.application.ApplicationEvents;
import javax.jws.WebParam;
import javax.jws.WebService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/**
 * This web service endpoint implementation performs basic validation and parsing
 * of incoming data, and in case of a valid registration attempt, sends an asynchronous message
 * with the information to the handling event registration system for proper registration.
 */
@WebService(endpointInterface = "com.aggregator.HandlingReportService")
public class HandlingReportServiceImpl implements HandlingReportService {
    private ApplicationEvents applicationEvents;

    private static final Log logger = LogFactory.getLog(HandlingReportServiceImpl.class);

    @Override
    public void submitReport(@WebParam(name = "arg0", targetNamespace = "")
    HandlingReport handlingReport) throws HandlingReportErrors_Exception {
        throw new IllegalStateException();
    }

    public void setApplicationEvents(ApplicationEvents applicationEvents) {
        throw new IllegalStateException();
    }
}