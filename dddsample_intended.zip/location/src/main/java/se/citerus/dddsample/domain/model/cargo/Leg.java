package se.citerus.dddsample.domain.model.cargo;
import java.util.Date;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.domain.model.voyage.Voyage;
import se.citerus.dddsample.domain.shared.ValueObject;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
/**
 * An itinerary consists of one or more legs.
 */
public class Leg implements ValueObject<Leg> {
    private Voyage voyage;

    private Location loadLocation;

    private Location unloadLocation;

    private Date loadTime;

    private Date unloadTime;

    public Leg(Voyage voyage, Location loadLocation, Location unloadLocation, Date loadTime, Date unloadTime) {
        Validate.noNullElements(new Object[]{ voyage, loadLocation, unloadLocation, loadTime, unloadTime });
        this.voyage = voyage;
        this.loadLocation = loadLocation;
        this.unloadLocation = unloadLocation;
        this.loadTime = loadTime;
        this.unloadTime = unloadTime;
    }

    public Voyage voyage() {
        throw new IllegalStateException();
    }

    public Location loadLocation() {
        throw new IllegalStateException();
    }

    public Location unloadLocation() {
        throw new IllegalStateException();
    }

    public Date loadTime() {
        throw new IllegalStateException();
    }

    public Date unloadTime() {
        throw new IllegalStateException();
    }

    @Override
    public boolean sameValueAs(final Leg other) {
        throw new IllegalStateException();
    }

    @Override
    public boolean equals(final Object o) {
        throw new IllegalStateException();
    }

    @Override
    public int hashCode() {
        throw new IllegalStateException();
    }

    Leg() {
        // Needed by Hibernate
    }

    // Auto-generated surrogate key
    private Long id;
}