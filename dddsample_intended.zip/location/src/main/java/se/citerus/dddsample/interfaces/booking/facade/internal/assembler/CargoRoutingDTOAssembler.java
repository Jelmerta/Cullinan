package se.citerus.dddsample.interfaces.booking.facade.internal.assembler;
import se.citerus.dddsample.domain.model.cargo.Cargo;
import se.citerus.dddsample.interfaces.booking.facade.dto.CargoRoutingDTO;
/**
 * Assembler class for the CargoRoutingDTO.
 */
public class CargoRoutingDTOAssembler {
    /**
     *
     * @param cargo
     * 		cargo
     * @return A cargo routing DTO
     */
    public CargoRoutingDTO toDTO(final Cargo cargo) {
        throw new IllegalStateException();
    }
}