package se.citerus.dddsample.domain.model.handling;
import client.rmiinterface.UnknownLocationExceptionInterface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import se.citerus.dddsample.domain.model.location.UnLocode;
import util.CullinanId;
import util.SerializationUtil;
import util.StorageManager;
public class UnknownLocationExceptionServiceImplementation extends UnicastRemoteObject implements UnknownLocationExceptionInterface {
    @Override
    public String getMessage(String objectReference) throws RemoteException {
        UnknownLocationException objectReferenceObject = ((UnknownLocationException) (SerializationUtil.decode(objectReference)));
        String result = objectReferenceObject.getMessage();
        return result;
    }

    public UnknownLocationExceptionServiceImplementation() throws RemoteException {
    }

    @Override
    public String newUnknownLocationException(String unlocodeReferenceId) {
        UnLocode unlocodeReferenceIdObject = ((UnLocode) (SerializationUtil.decode(unlocodeReferenceId)));
        UnknownLocationException newObject = ((UnknownLocationException) (new UnknownLocationException(unlocodeReferenceIdObject)));
        CullinanId id = StorageManager.add(newObject);
//        newObject.setReferenceId(id);
        return id.getIdValue();
    }
}