package se.citerus.dddsample.interfaces.booking.facade.dto;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 * DTO for registering and routing a cargo.
 */
public final class CargoRoutingDTO implements Serializable {
    private final String trackingId;

    private final String origin;

    private final String finalDestination;

    private final Date arrivalDeadline;

    private final boolean misrouted;

    private final List<LegDTO> legs;

    /**
     * Constructor.
     *
     * @param trackingId
     * @param origin
     * @param finalDestination
     * @param arrivalDeadline
     * @param misrouted
     */
    public CargoRoutingDTO(String trackingId, String origin, String finalDestination, Date arrivalDeadline, boolean misrouted) {
        this.trackingId = trackingId;
        this.origin = origin;
        this.finalDestination = finalDestination;
        this.arrivalDeadline = arrivalDeadline;
        this.misrouted = misrouted;
        this.legs = new ArrayList<LegDTO>();
    }

    public String getTrackingId() {
        throw new IllegalStateException();
    }

    public String getOrigin() {
        throw new IllegalStateException();
    }

    public String getFinalDestination() {
        throw new IllegalStateException();
    }

    public void addLeg(String voyageNumber, String from, String to, Date loadTime, Date unloadTime) {
        throw new IllegalStateException();
    }

    /**
     *
     * @return An unmodifiable list DTOs.
     */
    public List<LegDTO> getLegs() {
        throw new IllegalStateException();
    }

    public boolean isMisrouted() {
        throw new IllegalStateException();
    }

    public boolean isRouted() {
        throw new IllegalStateException();
    }

    public Date getArrivalDeadline() {
        throw new IllegalStateException();
    }
}