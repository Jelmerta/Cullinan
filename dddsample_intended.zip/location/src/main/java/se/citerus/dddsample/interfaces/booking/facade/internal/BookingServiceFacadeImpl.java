package se.citerus.dddsample.interfaces.booking.facade.internal;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;
import se.citerus.dddsample.application.BookingService;
import se.citerus.dddsample.domain.model.cargo.CargoRepository;
import se.citerus.dddsample.domain.model.location.LocationRepository;
import se.citerus.dddsample.domain.model.voyage.VoyageRepository;
import se.citerus.dddsample.interfaces.booking.facade.BookingServiceFacade;
import se.citerus.dddsample.interfaces.booking.facade.dto.CargoRoutingDTO;
import se.citerus.dddsample.interfaces.booking.facade.dto.LocationDTO;
import se.citerus.dddsample.interfaces.booking.facade.dto.RouteCandidateDTO;
/**
 * This implementation has additional support from the infrastructure, for exposing as an RMI
 * service and for keeping the OR-mapper unit-of-work open during DTO assembly,
 * analogous to the view rendering for web interfaces.
 */
public class BookingServiceFacadeImpl implements BookingServiceFacade {
    private BookingService bookingService;

    private LocationRepository locationRepository;

    private CargoRepository cargoRepository;

    private VoyageRepository voyageRepository;

    @Override
    public List<LocationDTO> listShippingLocations() {
        throw new IllegalStateException();
    }

    @Override
    public String bookNewCargo(String origin, String destination, Date arrivalDeadline) {
        throw new IllegalStateException();
    }

    @Override
    public CargoRoutingDTO loadCargoForRouting(String trackingId) {
        throw new IllegalStateException();
    }

    @Override
    public void assignCargoToRoute(String trackingIdStr, RouteCandidateDTO routeCandidateDTO) {
        throw new IllegalStateException();
    }

    @Override
    public void changeDestination(String trackingId, String destinationUnLocode) throws RemoteException {
        throw new IllegalStateException();
    }

    @Override
    public List<CargoRoutingDTO> listAllCargos() {
        throw new IllegalStateException();
    }

    @Override
    public List<RouteCandidateDTO> requestPossibleRoutesForCargo(String trackingId) throws RemoteException {
        throw new IllegalStateException();
    }

    public void setBookingService(BookingService bookingService) {
        throw new IllegalStateException();
    }

    public void setLocationRepository(LocationRepository locationRepository) {
        throw new IllegalStateException();
    }

    public void setCargoRepository(CargoRepository cargoRepository) {
        throw new IllegalStateException();
    }

    public void setVoyageRepository(VoyageRepository voyageRepository) {
        throw new IllegalStateException();
    }
}