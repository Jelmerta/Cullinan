package se.citerus.dddsample.interfaces.booking.facade.internal.assembler;
import java.util.List;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.interfaces.booking.facade.dto.LocationDTO;
public class LocationDTOAssembler {
    public LocationDTO toDTO(Location location) {
        throw new IllegalStateException();
    }

    public List<LocationDTO> toDTOList(List<Location> allLocations) {
        throw new IllegalStateException();
    }
}