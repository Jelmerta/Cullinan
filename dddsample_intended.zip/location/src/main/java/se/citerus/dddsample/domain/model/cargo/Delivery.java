package se.citerus.dddsample.domain.model.cargo;
import java.util.Date;
import se.citerus.dddsample.domain.model.handling.HandlingEvent;
import se.citerus.dddsample.domain.model.handling.HandlingHistory;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.domain.model.voyage.Voyage;
import se.citerus.dddsample.domain.shared.ValueObject;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
/**
 * The actual transportation of the cargo, as opposed to
 * the customer requirement (RouteSpecification) and the plan (Itinerary).
 */
public class Delivery implements ValueObject<Delivery> {
    private TransportStatus transportStatus;

    private Location lastKnownLocation;

    private Voyage currentVoyage;

    private boolean misdirected;

    private Date eta;

    private HandlingActivity nextExpectedActivity;

    private boolean isUnloadedAtDestination;

    private RoutingStatus routingStatus;

    private Date calculatedAt;

    private HandlingEvent lastEvent;

    private static final Date ETA_UNKOWN = null;

    private static final HandlingActivity NO_ACTIVITY = null;

    /**
     * Creates a new delivery snapshot to reflect changes in routing, i.e.
     * when the route specification or the itinerary has changed
     * but no additional handling of the cargo has been performed.
     *
     * @param routeSpecification
     * 		route specification
     * @param itinerary
     * 		itinerary
     * @return An up to date delivery
     */
    Delivery updateOnRouting(RouteSpecification routeSpecification, Itinerary itinerary) {
        throw new IllegalStateException();
    }

    /**
     * Creates a new delivery snapshot based on the complete handling history of a cargo,
     * as well as its route specification and itinerary.
     *
     * @param routeSpecification
     * 		route specification
     * @param itinerary
     * 		itinerary
     * @param handlingHistory
     * 		delivery history
     * @return An up to date delivery.
     */
    static Delivery derivedFrom(RouteSpecification routeSpecification, Itinerary itinerary, HandlingHistory handlingHistory) {
        throw new IllegalStateException();
    }

    /**
     * Internal constructor.
     *
     * @param lastEvent
     * 		last event
     * @param itinerary
     * 		itinerary
     * @param routeSpecification
     * 		route specification
     */
    private Delivery(HandlingEvent lastEvent, Itinerary itinerary, RouteSpecification routeSpecification) {
        this.calculatedAt = new Date();
        this.lastEvent = lastEvent;
        this.misdirected = calculateMisdirectionStatus(itinerary);
        this.routingStatus = calculateRoutingStatus(itinerary, routeSpecification);
        this.transportStatus = calculateTransportStatus();
        this.lastKnownLocation = calculateLastKnownLocation();
        this.currentVoyage = calculateCurrentVoyage();
        this.eta = calculateEta(itinerary);
        this.nextExpectedActivity = calculateNextExpectedActivity(routeSpecification, itinerary);
        this.isUnloadedAtDestination = calculateUnloadedAtDestination(routeSpecification);
    }

    /**
     *
     * @return Transport status
     */
    public TransportStatus transportStatus() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Last known location of the cargo, or Location.UNKNOWN if the delivery history is empty.
     */
    public Location lastKnownLocation() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Current voyage.
     */
    public Voyage currentVoyage() {
        throw new IllegalStateException();
    }

    /**
     * Check if cargo is misdirected.
     * <p/>
     * <ul>
     * <li>A cargo is misdirected if it is in a location that's not in the itinerary.
     * <li>A cargo with no itinerary can not be misdirected.
     * <li>A cargo that has received no handling events can not be misdirected.
     * </ul>
     *
     * @return <code>true</code> if the cargo has been misdirected,
     */
    public boolean isMisdirected() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Estimated time of arrival
     */
    public Date estimatedTimeOfArrival() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return The next expected handling activity.
     */
    public HandlingActivity nextExpectedActivity() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return True if the cargo has been unloaded at the final destination.
     */
    public boolean isUnloadedAtDestination() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return Routing status.
     */
    public RoutingStatus routingStatus() {
        throw new IllegalStateException();
    }

    /**
     *
     * @return When this delivery was calculated.
     */
    public Date calculatedAt() {
        throw new IllegalStateException();
    }

    // TODO add currentCarrierMovement (?)
    // --- Internal calculations below ---
    private TransportStatus calculateTransportStatus() {
        throw new IllegalStateException();
    }

    private Location calculateLastKnownLocation() {
        throw new IllegalStateException();
    }

    private Voyage calculateCurrentVoyage() {
        throw new IllegalStateException();
    }

    private boolean calculateMisdirectionStatus(Itinerary itinerary) {
        throw new IllegalStateException();
    }

    private Date calculateEta(Itinerary itinerary) {
        throw new IllegalStateException();
    }

    private HandlingActivity calculateNextExpectedActivity(RouteSpecification routeSpecification, Itinerary itinerary) {
        throw new IllegalStateException();
    }

    private RoutingStatus calculateRoutingStatus(Itinerary itinerary, RouteSpecification routeSpecification) {
        throw new IllegalStateException();
    }

    private boolean calculateUnloadedAtDestination(RouteSpecification routeSpecification) {
        throw new IllegalStateException();
    }

    private boolean onTrack() {
        throw new IllegalStateException();
    }

    @Override
    public boolean sameValueAs(final Delivery other) {
        throw new IllegalStateException();
    }

    @Override
    public boolean equals(final Object o) {
        throw new IllegalStateException();
    }

    @Override
    public int hashCode() {
        throw new IllegalStateException();
    }

    Delivery() {
        // Needed by Hibernate
    }
}