package se.citerus.dddsample.infrastructure.persistence.hibernate;
import java.util.List;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.domain.model.location.LocationRepository;
import se.citerus.dddsample.domain.model.location.UnLocode;
import org.springframework.stereotype.Repository;
@Repository
public class LocationRepositoryHibernate extends HibernateRepository implements LocationRepository {
    public Location find(final UnLocode unLocode) {
        throw new IllegalStateException();
    }

    public List<Location> findAll() {
        throw new IllegalStateException();
    }
}