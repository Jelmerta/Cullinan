package se.citerus.dddsample.domain.model.cargo;
import se.citerus.dddsample.domain.model.handling.HandlingEvent;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.domain.model.voyage.Voyage;
import se.citerus.dddsample.domain.shared.ValueObject;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
/**
 * A handling activity represents how and where a cargo can be handled,
 * and can be used to express predictions about what is expected to
 * happen to a cargo in the future.
 */
public class HandlingActivity implements ValueObject<HandlingActivity> {
    // TODO make HandlingActivity a part of HandlingEvent too? There is some overlap.
    private HandlingEvent.Type type;

    private Location location;

    private Voyage voyage;

    public HandlingActivity(final HandlingEvent.Type type, final Location location) {
        Validate.notNull(type, "Handling event type is required");
        Validate.notNull(location, "Location is required");
        this.type = type;
        this.location = location;
    }

    public HandlingActivity(final HandlingEvent.Type type, final Location location, final Voyage voyage) {
        Validate.notNull(type, "Handling event type is required");
        Validate.notNull(location, "Location is required");
        Validate.notNull(location, "Voyage is required");
        this.type = type;
        this.location = location;
        this.voyage = voyage;
    }

    public HandlingEvent.Type type() {
        throw new IllegalStateException();
    }

    public Location location() {
        throw new IllegalStateException();
    }

    public Voyage voyage() {
        throw new IllegalStateException();
    }

    @Override
    public boolean sameValueAs(final HandlingActivity other) {
        throw new IllegalStateException();
    }

    @Override
    public int hashCode() {
        throw new IllegalStateException();
    }

    @Override
    public boolean equals(final Object obj) {
        throw new IllegalStateException();
    }

    HandlingActivity() {
        // Needed by Hibernate
    }
}