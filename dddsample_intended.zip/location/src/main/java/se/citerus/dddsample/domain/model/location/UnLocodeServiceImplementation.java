package se.citerus.dddsample.domain.model.location;
import client.rmiinterface.UnLocodeInterface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class UnLocodeServiceImplementation extends UnicastRemoteObject implements UnLocodeInterface {
    @Override
    public String idString(String objectReference) throws RemoteException {
        return UnLocodeManager.idString(objectReference);
    }

    @Override
    public boolean equals(String objectReference, final String o) throws RemoteException {
        return UnLocodeManager.equals(objectReference, o);
    }

    @Override
    public int hashCode(String objectReference) throws RemoteException {
        return UnLocodeManager.hashCode(objectReference);
    }

    @Override
    public boolean sameValueAs(String objectReference, String other) throws RemoteException {
        return UnLocodeManager.sameValueAs(objectReference, other);
    }

    @Override
    public String toString(String objectReference) throws RemoteException {
        return UnLocodeManager.toString(objectReference);
    }

    public UnLocodeServiceImplementation() throws RemoteException {
    }

    @Override
    public String newUnLocode() {
        return UnLocodeManager.newUnLocode().getReferenceId().getIdValue();
    }

    @Override
    public String newUnLocode(final String countryAndLocation) {
        return UnLocodeManager.newUnLocode(countryAndLocation).getReferenceId().getIdValue(); // TODO Or just simply call the SerializationUtil for everything?
    }

    @Override
    public String findLocation(String referenceId) throws RemoteException {
        return UnLocodeManager.findLocation(referenceId);
    }
}