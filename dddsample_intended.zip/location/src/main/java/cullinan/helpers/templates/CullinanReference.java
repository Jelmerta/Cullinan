package cullinan.helpers.templates;
public interface CullinanReference {
    String getReference();
}