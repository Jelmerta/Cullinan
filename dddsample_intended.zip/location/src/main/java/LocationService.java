import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import se.citerus.dddsample.domain.model.handling.UnknownLocationExceptionServiceImplementation;
import se.citerus.dddsample.domain.model.location.LocationServiceImplementation;
import se.citerus.dddsample.domain.model.location.SampleLocationsServiceImplementation;
import se.citerus.dddsample.domain.model.location.UnLocodeServiceImplementation;
import util.StorageManager;

public class LocationService {
    private static final int registryPort = 1099;

    public static void main(String[] args) {
        StorageManager.loadData();

        try {
            Registry registry = LocateRegistry.createRegistry(registryPort);
            UnknownLocationExceptionServiceImplementation unknownLocationExceptionServiceImplementation = new UnknownLocationExceptionServiceImplementation();
            registry.rebind("//localhost/UnknownLocationException", unknownLocationExceptionServiceImplementation);
            UnLocodeServiceImplementation unLocodeServiceImplementation = new UnLocodeServiceImplementation();
            registry.rebind("//localhost/UnLocode", unLocodeServiceImplementation);
            LocationServiceImplementation locationServiceImplementation = new LocationServiceImplementation();
            registry.rebind("//localhost/Location", locationServiceImplementation);
            SampleLocationsServiceImplementation sampleLocationsServiceImplementation = new SampleLocationsServiceImplementation();
            registry.rebind("//localhost/SampleLocations", sampleLocationsServiceImplementation);
        } catch (Exception e) {
        }
    }
}