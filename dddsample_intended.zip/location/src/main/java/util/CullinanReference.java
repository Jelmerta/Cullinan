package util;
public interface CullinanReference {
    CullinanId getReferenceId();

    void setReferenceId(CullinanId referenceId);
}