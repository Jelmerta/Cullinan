package util;
import se.citerus.dddsample.domain.model.location.Location;
import se.citerus.dddsample.domain.model.location.UnLocode;
import se.citerus.dddsample.domain.model.location.UnLocodeManager;

import java.util.HashMap;
import java.util.UUID;

// TODO I really feel like this should be split  up for each object, especially as there might be different business rules. UnLOcode for example requires to be unique. Should probably return an error when we try to add a second UnLocode with the same country reference.
// I mean i guess we could do this in the onstructor as well.

// This is the only data that the original code base had in the database, rest was dynamic?
//         Object[][] locationArgs = {
//                {1, "SESTO", "Stockholm"},
//                {2, "AUMEL", "Melbourne"},
//                {3, "CNHKG", "Hongkong"},
//                {4, "JPTOK", "Tokyo"},
//                {5, "FIHEL", "Helsinki"},
//                {6, "DEHAM", "Hamburg"},
//                {7, "USCHI", "Chicago"}
//        };
public class StorageManager {
    private StorageManager() {
    }

    private static HashMap<CullinanId, Object> storage = new HashMap<>();

    public static HashMap<CullinanId, Object> getStorage() {
        return storage;
    }

    public static Object get(CullinanId id) {
        return storage.get(id);
    }

    public static CullinanId add(Object t) {
        UUID id = UUID.randomUUID();
        String uuidAsString = id.toString();
        String storageId = (t.getClass().getName() + "::") + uuidAsString;// TODO Probably make a helper for id creation based on class + reference id

        CullinanId cullinanId = new CullinanId(storageId);
        CullinanReference objectAsReference = (CullinanReference) t;
        objectAsReference.setReferenceId(cullinanId);
        // TODO We would like to put the reference id in the object here if we could.
        // TODO Can we assume the object always implements CullinanReference? I feel like it would...?
        storage.put(cullinanId, t);
        return cullinanId;
    }

    // Makes sure data is loaded before being accessed.
    public static void loadData() {
        Location STOCKHOLM = new Location(UnLocodeManager.newUnLocode("SESTO"), "Stockholm");
        STOCKHOLM.setReferenceId(new CullinanId("se.citerus.dddsample.domain.model.location.Location::1"));
        storage.put(STOCKHOLM.getReferenceId(), STOCKHOLM);

        Location MELBOURNE = new Location(UnLocodeManager.newUnLocode("AUMEL"), "Melbourne");
        MELBOURNE.setReferenceId(new CullinanId("se.citerus.dddsample.domain.model.location.Location::2"));
        storage.put(MELBOURNE.getReferenceId(), MELBOURNE);

        Location HONGKONG = new Location(UnLocodeManager.newUnLocode("CNHKG"), "Hongkong");
        HONGKONG.setReferenceId(new CullinanId("se.citerus.dddsample.domain.model.location.Location::3"));
        storage.put(HONGKONG.getReferenceId(), HONGKONG);

        Location TOKYO = new Location(UnLocodeManager.newUnLocode("JPTOK"), "Tokyo");
        TOKYO.setReferenceId(new CullinanId("se.citerus.dddsample.domain.model.location.Location::4"));
        storage.put(TOKYO.getReferenceId(), TOKYO);

        Location HELSINKI = new Location(UnLocodeManager.newUnLocode("FIHEL"), "Helsinki");
        HELSINKI.setReferenceId(new CullinanId("se.citerus.dddsample.domain.model.location.Location::5"));
        storage.put(HELSINKI.getReferenceId(), HELSINKI);

        Location HAMBURG = new Location(UnLocodeManager.newUnLocode("DEHAM"), "Hamburg");
        HAMBURG.setReferenceId(new CullinanId("se.citerus.dddsample.domain.model.location.Location::6"));
        storage.put(HAMBURG.getReferenceId(), HAMBURG);

        Location CHICAGO = new Location(UnLocodeManager.newUnLocode("USCHI"), "Chicago");
        CHICAGO.setReferenceId(new CullinanId("se.citerus.dddsample.domain.model.location.Location::7"));
        storage.put(CHICAGO.getReferenceId(), CHICAGO);
    }
}