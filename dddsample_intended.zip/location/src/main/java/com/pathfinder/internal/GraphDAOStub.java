package com.pathfinder.internal;
import java.util.List;
import java.util.Random;
public class GraphDAOStub implements GraphDAO {
    private static final Random random = new Random();

    public List<String> listAllNodes() {
        throw new IllegalStateException();
    }

    public String getTransitEdge(String from, String to) {
        throw new IllegalStateException();
    }
}