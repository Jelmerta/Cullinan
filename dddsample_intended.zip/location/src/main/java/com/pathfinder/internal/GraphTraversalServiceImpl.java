package com.pathfinder.internal;
import com.pathfinder.api.GraphTraversalService;
import com.pathfinder.api.TransitPath;
import java.util.*;
public class GraphTraversalServiceImpl implements GraphTraversalService {
    private GraphDAO dao;

    private Random random;

    private static final long ONE_MIN_MS = 1000 * 60;

    private static final long ONE_DAY_MS = (ONE_MIN_MS * 60) * 24;

    public GraphTraversalServiceImpl(GraphDAO dao) {
        this.dao = dao;
        this.random = new Random();
    }

    public List<TransitPath> findShortestPath(final String originNode, final String destinationNode, final Properties limitations) {
        throw new IllegalStateException();
    }

    private Date nextDate(Date date) {
        throw new IllegalStateException();
    }

    private int getRandomNumberOfCandidates() {
        throw new IllegalStateException();
    }

    private List<String> getRandomChunkOfNodes(List<String> allNodes) {
        throw new IllegalStateException();
    }
}