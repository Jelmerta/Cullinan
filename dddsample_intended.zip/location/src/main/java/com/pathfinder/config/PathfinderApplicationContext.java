package com.pathfinder.config;
import com.pathfinder.api.GraphTraversalService;
import com.pathfinder.internal.GraphDAO;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class PathfinderApplicationContext {
    private GraphDAO graphDAO() {
        throw new IllegalStateException();
    }

    @Bean
    public GraphTraversalService graphTraversalService() {
        throw new IllegalStateException();
    }
}