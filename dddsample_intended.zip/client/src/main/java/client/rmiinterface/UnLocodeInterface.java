package client.rmiinterface;
import java.rmi.Remote;
import java.rmi.RemoteException;
public interface UnLocodeInterface extends Remote {
    boolean equals(String referenceId, final String o) throws RemoteException;

    int hashCode(String referenceId) throws RemoteException;

    String idString(String referenceId) throws RemoteException;

    boolean sameValueAs(String referenceId, String otherReferenceId) throws RemoteException;

    String toString(String referenceId) throws RemoteException;

    String newUnLocode() throws RemoteException;

    String newUnLocode(final String countryAndLocation) throws RemoteException;

    String findLocation(String referenceId) throws RemoteException;

}