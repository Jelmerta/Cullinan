package client.rmiinterface;
import java.rmi.Remote;
import java.rmi.RemoteException;
public interface UnknownLocationExceptionInterface extends Remote {
    String getMessage(String referenceId) throws RemoteException;

    String newUnknownLocationException(final String unlocodeReferenceId) throws RemoteException;
}