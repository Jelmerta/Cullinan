package client.rmiinterface;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface LocationInterface extends Remote {
    boolean equals(String referenceId, final String object) throws RemoteException;

    int hashCode(String referenceId) throws RemoteException;

    String name(String referenceId) throws RemoteException;

    boolean sameIdentityAs(String referenceId, final String otherReferenceId) throws RemoteException;

    String toString(String referenceId) throws RemoteException;

    String unLocode(String referenceId) throws RemoteException;

    String newLocation() throws RemoteException;

    String newLocation(final String unLocodeReferenceId, final String name) throws RemoteException;

    List<String> findAll() throws RemoteException;
}