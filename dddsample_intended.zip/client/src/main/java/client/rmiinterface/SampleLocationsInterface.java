package client.rmiinterface;
import java.rmi.Remote;
import java.rmi.RemoteException;
public interface SampleLocationsInterface extends Remote {
    String newSampleLocations() throws RemoteException;

    String getConstant(String constant) throws RemoteException;
}