package demo;

public class Rental {
    private static long RENTAL_COUNTER = 0;
    private long rentalId;
    private long accountId;
    private long vehicleId;
    private String status;

    public Rental(long accountId, long vehicleId) {
        this.rentalId = RENTAL_COUNTER++;
        this.accountId = accountId;
        this.vehicleId = vehicleId;
        this.status = "Created";
    }

    public void start() {
        this.status = "Started";
        System.out.println("demo.Rental: demo.Rental " + rentalId + " has started!");
    }

    public void stop() {
        this.status = "Stopped";
        System.out.println("demo.Rental: demo.Rental " + rentalId + " has stopped!");
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "demo.Rental with id " + rentalId + " has the following attributes:\n" +
                "Account id: " + accountId + "\n" +
                "Vehicle id: " + vehicleId + "\n" +
                "Status: " + status + "\n";
    }
}
