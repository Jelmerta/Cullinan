package demo;

public class CullinanDemo {

    public static void main(String[] args) {
        // Let's make a rental for account 5 for vehicle 9!
        long accountId = 5;
        long vehicleId = 9;

        Rental rental = new Rental(accountId, vehicleId);
        System.out.println("Monolith: Creation status: " + rental.getStatus() + "\n");

        rental.start();
        System.out.println("Monolith: Start status: " + rental.getStatus() + "\n");

        rental.stop();
        System.out.println("Monolith: Stop status: " + rental.getStatus() + "\n\n\n");

        // Let's do another:
        accountId = 12;
        vehicleId = 22;
        Rental rentalTwo = new Rental(accountId, vehicleId);
        System.out.println("Monolith: Creation status: " + rentalTwo.getStatus() + "\n");

        rentalTwo.start();
        System.out.println("Monolith: Start status: " + rentalTwo.getStatus() + "\n");

        rentalTwo.stop();
        System.out.println("Monolith: Stop status: " + rentalTwo.getStatus() + "\n\n");
    }
}
